"""
SSH Manager - 다중 SSH 서버 관리 및 동시 작업 도구
"""

__version__ = "1.0.0"
__author__ = "SSH Manager"

