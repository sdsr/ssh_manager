from textual.widgets._tabs import Tab

__all__ = ["Tab"]
