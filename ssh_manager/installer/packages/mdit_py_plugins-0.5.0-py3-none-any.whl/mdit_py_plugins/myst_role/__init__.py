from .index import myst_role_plugin

__all__ = ("myst_role_plugin",)
