from .index import admon_plugin

__all__ = ("admon_plugin",)
